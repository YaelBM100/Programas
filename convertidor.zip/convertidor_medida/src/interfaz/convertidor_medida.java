
package interfaz;

import java.awt.Image;
import javax.swing.ImageIcon;

public class convertidor_medida extends javax.swing.JFrame {

    public convertidor_medida() {
        initComponents();
        this.setResizable(false); //codigo para bloquear la opcion de maximizar
        setLocationRelativeTo(null);//codigo para hacer que nuestro programa aparesca en el centro.
        
        //Código para poner icono a la aplicacion 
        Image icon=new ImageIcon(getClass().getResource("/interfaz/app.png")).getImage();
        setIconImage(icon);
    }

   
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        unidad = new javax.swing.JTextField();
        combomedida = new javax.swing.JComboBox<>();
        res = new javax.swing.JTextField();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jPanel1.setBackground(new java.awt.Color(153, 153, 255));
        jPanel1.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));

        jLabel1.setFont(new java.awt.Font("Franklin Gothic Medium Cond", 1, 24)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(0, 0, 0));
        jLabel1.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel1.setText("CONVERTIDOR DE MEDIDAS");

        jLabel2.setFont(new java.awt.Font("Franklin Gothic Medium Cond", 1, 18)); // NOI18N
        jLabel2.setForeground(new java.awt.Color(0, 0, 0));
        jLabel2.setText("Ingrese valor en metros:");

        unidad.setBackground(new java.awt.Color(255, 255, 255));
        unidad.setForeground(new java.awt.Color(0, 0, 0));
        unidad.setHorizontalAlignment(javax.swing.JTextField.RIGHT);

        combomedida.setBackground(new java.awt.Color(255, 255, 255));
        combomedida.setFont(new java.awt.Font("Franklin Gothic Medium Cond", 1, 18)); // NOI18N
        combomedida.setForeground(new java.awt.Color(0, 0, 0));
        combomedida.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Convertir a", "Centimetros", "Metros", "Kilometros", "Decimetros", "Decametros" }));
        combomedida.setToolTipText("");
        combomedida.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                combomedidaActionPerformed(evt);
            }
        });

        res.setBackground(new java.awt.Color(255, 255, 255));
        res.setForeground(new java.awt.Color(0, 0, 0));
        res.setHorizontalAlignment(javax.swing.JTextField.RIGHT);

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(33, 33, 33)
                        .addComponent(jLabel1))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addContainerGap()
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                            .addComponent(combomedida, javax.swing.GroupLayout.Alignment.LEADING, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(jLabel2, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                        .addGap(27, 27, 27)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(unidad, javax.swing.GroupLayout.PREFERRED_SIZE, 112, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(res, javax.swing.GroupLayout.PREFERRED_SIZE, 112, javax.swing.GroupLayout.PREFERRED_SIZE))))
                .addContainerGap(24, Short.MAX_VALUE))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel1)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 7, Short.MAX_VALUE)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel2)
                    .addComponent(unidad, javax.swing.GroupLayout.DEFAULT_SIZE, 30, Short.MAX_VALUE))
                .addGap(18, 18, 18)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(combomedida, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(res, javax.swing.GroupLayout.DEFAULT_SIZE, 30, Short.MAX_VALUE))
                .addGap(177, 177, 177))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void combomedidaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_combomedidaActionPerformed
       double dato1, resultado;
       dato1=Double.parseDouble(unidad.getText());
       String option =(String)combomedida.getSelectedItem();
       
       if(option.equals("Centimetros")){
           resultado=dato1*100;
           res.setText(""+ resultado +" cm");
       }
       if(option.equals("Metros")){
           resultado=dato1;
           res.setText(""+resultado+" m");
       }
       if(option.equals("Kilometros")){
           resultado=dato1/1000;
           res.setText(""+resultado+" km");
       }
       if(option.equals("Decimetros")){
           resultado=dato1*10;
           res.setText(""+resultado+" dm");
       }
       if(option.equals("Decametros")){
           resultado=dato1/10;
           res.setText(""+resultado+" dam");              
       } 
    }//GEN-LAST:event_combomedidaActionPerformed

    
    public static void main(String args[]) {
        
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new convertidor_medida().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JComboBox<String> combomedida;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JTextField res;
    private javax.swing.JTextField unidad;
    // End of variables declaration//GEN-END:variables
}
