# formulario_simple_register
Esto es un formulario HTML sencillo, que registra y almacena datos a la base de datos.

## ESTO ES UN TRABAJO FORMULARIO HMTL SENCILLO
---
## screenshot
---
![CAPTURA DE PANTALLA](http://imgfz.com/i/p49AobF.jpeg)
